a = 'Kill me'
print (len(a))


first = 1
second = 6
summa = first + second
diff = first - second
print(summa)
print(diff)


first = 1
second = 2
third = 3
mean=(first + second + third)/ 3
print(mean)

first_string = "Понедельник"
second_string = "Вторник"
print( first_string + ", " + second_string )

a = 1
b = 2
c = 3
f = (a*b)+(a*c)
d = (f**3)/2
print(d)
